<?php
/*
	Template Name: ACF Custom Menu
*/
get_header();?>

<?php
/**
 * Field Structure:
 *
 * - main_menu_repeater (Repeater)
 *   - parent_menu_title (Text)
 *   - child_sub_menu_repeater (Repeater)
 *     - child_sub_menu_text (Text)
 */
if( have_rows('main_menu','option') ):
    while( have_rows('main_menu','option') ) : the_row();

        // Get parent value.
        $parent_menu 		= get_sub_field('parent_menu');
        $parent_menu_link   = get_sub_field('parent_menu_link');
        $short_description  = get_sub_field('short_description');
        echo '<h1>'.$parent_menu.'</h2>';
        ?>
        <form method="get" id="menusearch">
		  <fieldset>
		    	<input id="target" type="text" value="">
		  </fieldset>
		</form>
        <?php

        	

        // Loop over sub repeater rows.
        if( have_rows('sub_menu','option') ):
            while( have_rows('sub_menu','option') ) : the_row();

                // Get sub value.
                $sub_menu_text = get_sub_field('sub_menu_text');

                echo '<h2>'.$sub_menu_text.'</h2>';

                /*---- Start 3rd Nested Repeater ----*/
                	if( have_rows('nested_menu','option') ):
			            while( have_rows('nested_menu','option') ) : the_row();

			                // Get sub value.
			                $nested_menu_name = get_sub_field('nested_menu_name');
			                echo '<h3>'.$nested_menu_name.'</h2>';

			            endwhile;
        			endif;
                /*---- End   3rd Nested Repeater ----*/


            endwhile;
        endif;
    endwhile;
endif;
?>

<?php get_footer(); ?>