<?php
/*
	Template Name: Webinars-Events
*/
get_header();?>

<?php $categories = get_terms('category', array('order' => 'DESC')); ?>
<main class="main-content">


    <section class="webevents innerspacing news-list-grid-sec">
        <div class="grid-container">
            <div class="grid-x grid-padding-x">
                <div class="large-12 cell">
                    <div class="top_select">
                        <div class="selet_item">
                            <center><select id="cat_select">
                                <option value="">All Webinars & Events</option>
                                <?php
                                foreach($categories as $cat) 
                                { ?>
                                    <option value="<?php echo $cat->slug; ?>"><?php echo $cat->name; ?></option>
                                <?php 
                                } ?>
                            </select></center>
                        </div>                        
                    </div>
                </div>
                <div class="large-12 medium-12 small-12 cell news-list-grid" id="webinar_event_container">
                        <!---- Get Record ---->
                </div>
                
                <center><div class="large-12 medium-12 small-12 cell">
                    <div class="view_btn" id="view_btn" style="display: none;">
                        <a href="#" id="more_posts">VIEW MORE</a>
                    </div>
                </div></center>
           

            </div>
        </div>
    </section>

</main>	



<?php
//require get_template_directory() . '/template-parts/flexible_content.php';
get_footer();
?>