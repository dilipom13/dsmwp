<?php
/*
    Template Name: List Blog
*/
get_header();?>

<section id="primary" class="content-area">
	<div id="content" class="site-content" role="main">    
	<?php
    /*if( have_posts() ):
        while( have_posts() ): the_post();
            //get_template_part('content');
            get_template_part( 'template-parts/content', get_post_type() );
        endwhile;
    endif;*/
    ?>
    
    <div class="entry-content">
        <div id="genre-list-blog-filter">
            <?php echo get_list_blog_filters(); ?>
        </div>
        <div id="genre-list-blog-results"></div>
    </div>
    
	</div>
</section>


<?php get_footer(); ?>