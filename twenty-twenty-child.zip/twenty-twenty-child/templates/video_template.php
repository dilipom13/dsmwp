<?php
/*
    Template Name:  Video Template
*/
get_header();?>
<a class="popup-player" href="http://bftechnosoft.com/airpropty/wp-content/uploads/2020/06/25-2020new1.mp4">MP4 Video</a>
<?php get_footer(); ?>