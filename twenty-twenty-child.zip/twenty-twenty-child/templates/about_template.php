<?php
/*
    Template Name: About Blog Template
*/
get_header();?>

<div class="searchform">
    <div class="grid-container">
        <div class="grid-x">
            <div class="cell small-12 medium-12 large-12">
                <form id="searchform" class="search-field-box" onsubmit="event.preventDefault();">
                    <span>Search:</span>
                    <input type="text" class="search-field" name="filter_title_record" id="filter_title_record" placeholder="" />
                    <input type="button" class="btn green" id="search_buuton" value="Search" >
                </form>
                <ul class="cat_list">
                    <?php
                    foreach (range('A', 'Z') as $char) {
                        echo '<li><a href="#">' . $char . '</a></li>';
                    }
                    ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="list_recod_dd" id="like_counter">
    <div class="grid-container">
        <div class="grid-x">
            <div class="cell small-12 medium-12 large-12 logo-part">

                <div class="list_recod our-services-p">
                    <div class="record-cover container cf load_d">


                        <?php
                        $paged = get_query_var('paged') ? get_query_var('paged') : 1;

                        $args = array(
                            'post_type' => 'events',
                            'orderby' => 'title',
                            'order' => 'ASC',
                            'posts_per_page' => 10,
                            'paged' => $paged
                        );
                        $the_query = new WP_Query($args);
                        $totalPost = $the_query->found_posts;
                        $i = 1;
                        $title_2 = 'A';
                        echo '<h3 class="h2">' . $title_2 . '</h3>';
                        if ($the_query->have_posts()) :
                            while ($the_query->have_posts()) : $the_query->the_post();
                                $post_ID = get_the_id();
                                ?>
                                <?php
                                $title = get_the_title();
                                $title_1 = $title[0];
                                if ($title_1 !== $title_2) {
                                    echo '<h3 data-id="' . $title_1 . '">' . $title_1 . '</h3>';
                                    $title_2 = $title_1;
                                }
                                ?>
                                <div class="record-cover-box">
                                    <h4 class="h2"><?php echo get_the_title(); ?></h4>
                                    <div class="glossary_content"><p><?php echo get_the_content(); ?></p>
                                        <a href="<?php echo get_the_permalink(); ?>">Read More ></a>
                                    </div>
                                </div>
                                <?php
                                $i++;
                            endwhile;
                            ?><input type="hidden" id="xyz" name="xyz" value="<?php echo $title_2; ?>"><?php
                            wp_reset_postdata();
                        endif;
                        ?>
                    </div>
                    <!-- <div class="text-center loading" style="display: none;"><h2>Loading . . .</h2></div> -->
                    <div class="load-more loadmore">
                        <input type="hidden" name="offset" id="offset" value="10">
                        <input type="hidden" name="post_count" value="<?php echo $totalPost; ?>" id="post_count">
                        <a href="javascript:;" id="More_items" title="Load more"><div class="btn button-cta grey gray line">Load more</div></a>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php get_footer();?>