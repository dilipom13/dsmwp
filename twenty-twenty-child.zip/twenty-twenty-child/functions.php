<?php
/**
 * Twenty Twenty functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty
 * @since Twenty Twenty 1.0
 */

/**
 * Table of Contents:
 * Theme Support
 * Required Files
 * Register Styles
 * Register Scripts
 * Register Menus
 * Custom Logo
 * WP Body Open
 * Register Sidebars
 * Enqueue Block Editor Assets
 * Enqueue Classic Editor Styles
 * Block Editor Settings
 */

/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */

/*---- Start Load More Webinar & Events ----*/

add_action('wp_enqueue_scripts', 'misha_script_and_styles');
 
function misha_script_and_styles() {
	/*if(is_page('webinar-events')){*/
		global $wp_query;
		wp_register_script( 'webinar_events_script', get_stylesheet_directory_uri().'/assets/js/general.js', array('jquery'),'1.0', true );
		wp_localize_script( 'webinar_events_script', 'webi_event_param', array(
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
			'current_page' => get_query_var( 'paged' ) ? get_query_var('paged') : 1,
			'cat_slug' => get_query_var( 'cat_slug' ) ? get_query_var('cat_slug') : '',
		) );
		wp_enqueue_script( 'webinar_events_script' );
	/*}*/
}


add_action('wp_ajax_load_more_post_data', 'fn_load_more_post_data');
add_action('wp_ajax_nopriv_load_more_post_data', 'fn_load_more_post_data');

function fn_load_more_post_data() {

                        $per_page = 1;
                        $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;
                        $cat_slug   = isset( $_POST['cat_slug']) ? $_POST['cat_slug'] :'';
                         $args=array(
                          'post_type' => 'post',
                          'post_status' => 'publish',
                           'posts_per_page' => $per_page,
                           'paged'          =>  $_POST['paged'],
                          'order' => 'ASC'
                          );

                         if(!empty($_POST['cat_slug']))
                         {
                             $args['tax_query'] = array(
                            array(
                            'taxonomy' => 'category',
                            'field' => 'slug',
                            'terms' => $_POST['cat_slug']
                            )
                            );
                         }
                        

                        $the_query = new WP_Query($args);
						$totalPost = $the_query->found_posts;
                         if ($the_query->have_posts()) :
                            ob_start();
                             $i=1;
                            while ($the_query->have_posts()) : $the_query->the_post();
                                $post_ID = get_the_id();
                               
                    ?>

                    <div class="webevent_box">
                        <div class="webevbox_inner">
                            <div class="webevbox_wrapper">
								<?php
                                	$categories = get_the_terms( $post_ID, 'category' );
									foreach( $categories as $category ) 
									{
                                    	?><label><?php echo $category->name; ?></label>
                                    <?php
                                    }
                                    ?>
                                <?php

									$featured_img_url = get_the_post_thumbnail_url($post->ID, 'full');
									?>
									<figure>
                                    	<img src="<?php echo $featured_img_url; ?>" alt="" width="200" height="200">
                                    </figure>
									<h2><?php the_title(); ?></h2>
									<?php the_content(); ?>
                            </div>
                        </div>
                    </div>
                    <?php
                         $i++;
                     endwhile;

                        $html_data = ob_get_clean();
                        $max_pagination = $the_query->max_num_pages;
                         endif;
                        echo json_encode(array('html_data' => $html_data, 'max_page' => $max_pagination));
                        wp_reset_postdata();
                        wp_die();
}
/*---- End Load More Webinar & Events ----*/

/*---- Start Video Popup Template ----*/
function magnific_popup_script(){
    
    wp_enqueue_style( 'magnific-popup',get_stylesheet_directory_uri().'/assets/css/magnific-popup.css');
    wp_register_script( 'jquery.magnific-popup', get_stylesheet_directory_uri().'/assets/js/jquery.magnific-popup.js', array( 'jquery' ), '1.0', true );
    wp_enqueue_script( 'jquery.magnific-popup' );
}
add_action('wp_enqueue_scripts','magnific_popup_script');

/*---- End Video Popup Template ----*/

//Register books post type
function codex_custom_init() {
    $args = array(
		'public' => true,
		'label'  => 'Books'
    );
    register_post_type( 'book', $args );
}
add_action( 'init', 'codex_custom_init' );

//Register book genre taxonomy
add_action( 'init', 'create_book_tax' );

function create_book_tax() {
	register_taxonomy(
		'genre',
		'book',
		array(
			'label' => __( 'Genre' ),
			'rewrite' => array( 'slug' => 'genre' ),
			'hierarchical' => true
		)
	);
}

//Get Genre Filters
function get_genre_filters()
{
	$terms = get_terms('genre');
	$filters_html = false;
	
	if( $terms ):
		$filters_html = '<ul>';
		
		foreach( $terms as $term )
		{
			$term_id = $term->term_id;
			$term_name = $term->name;
		
			$filters_html .= '<li class="term_id_'.$term_id.'">'.$term_name.'<input type="checkbox" name="filter_genre[]" value="'.$term_id.'"></li>';	
		}
		$filters_html .= '<li class="clear-all">Clear All</li>';
		$filters_html .= '</ul>';
		
		return $filters_html;
	endif;
}

//Enqueue Ajax Scripts
function enqueue_genre_ajax_scripts() {
	
	if(is_page( 'my-book' ))
	{
		wp_register_script( 'genre-ajax-js', get_stylesheet_directory_uri(). '/assets/js/genre.js', array( 'jquery' ), '', true );
    	wp_localize_script( 'genre-ajax-js', 'ajax_genre_params', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
		wp_enqueue_script( 'genre-ajax-js' );
	}
	if(is_page( 'list-blog' ))
	{
		wp_register_script( 'coustom-general-ajax-js', get_stylesheet_directory_uri(). '/assets/js/coustom-general.js', array( 'jquery' ), '', true );
    	wp_localize_script( 'coustom-general-ajax-js', 'ajax_coustom_general_params', array( 'ajax_url' => admin_url( 'admin-ajax.php' ) ) );
		wp_enqueue_script( 'coustom-general-ajax-js' );
	}
	
}
add_action('wp_enqueue_scripts', 'enqueue_genre_ajax_scripts');

//Add Ajax Actions
add_action('wp_ajax_genre_filter', 'ajax_genre_filter');
add_action('wp_ajax_nopriv_genre_filter', 'ajax_genre_filter');

//Construct Loop & Results
function ajax_genre_filter()
{
	$query_data = $_GET;
	
	$genre_terms = ($query_data['genres']) ? explode(',',$query_data['genres']) : false;
	
	$tax_query = ($genre_terms) ? array( array(
		'taxonomy' => 'genre',
		'field' => 'id',
		'terms' => $genre_terms
	) ) : false;
	
	$search_value = ($query_data['search']) ? $query_data['search'] : false;
	
	$paged = (isset($query_data['paged']) ) ? intval($query_data['paged']) : 1;
	
	$book_args = array(
		'post_type' => 'book',
		's' => $search_value,
		'posts_per_page' => 2,
		'tax_query' => $tax_query,
		'paged' => $paged
	);
	$book_loop = new WP_Query($book_args);
	
	if( $book_loop->have_posts() ):
		while( $book_loop->have_posts() ): $book_loop->the_post();
			//get_template_part('content');
			get_template_part( 'template-parts/content', get_post_type() );
		endwhile;
		
		echo '<div class="genre-filter-navigation">';
		$big = 999999999;
		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
			'format' => '?paged=%#%',
			'current' => max( 1, $paged ),
			'total' => $book_loop->max_num_pages
		) );
		echo '</div>';	
	else:
		get_template_part('content-none');
	endif;
	wp_reset_postdata();
	
	die();
}


// Start List Blog
function get_list_blog_filters()
{
	$terms = get_terms('category');
	$filters_list_blog_html = false;
	if( $terms ):
		$filters_list_blog_html = "<select id='blog_list' class='blog_list' multiple='multiple'>";
		$filters_list_blog_html .= '<option value="">Select One or More Options</option>';
		foreach( $terms as $term)
		{
			$term_id = $term->term_id;
			$term_name = $term->name;
			$filters_list_blog_html .= '<option value="'.$term_id.'">'.$term_name.'</option>';
		}
		$filters_list_blog_html .= "</select>";
		return $filters_list_blog_html;
	endif;
}



//Add Ajax Actions
add_action('wp_ajax_general_dat_filter', 'ajax_general_dat_filter');
add_action('wp_ajax_nopriv_general_dat_filter', 'ajax_general_dat_filter');

//Construct Loop & Results
function ajax_general_dat_filter()
{
	echo 'Hello';
	$query_data = $_GET;
	echo '<pre>';
	print_r($query_data);
	die();
}



//---- Start Create Team Coustom Post Type Field ----
function my_custom_post_team() {
	$labels = array(
	  'name'               => _x( 'Teams', 'post type general name' ),
	  'singular_name'      => _x( 'Team', 'post type singular name' ),
	  'add_new'            => _x( 'Add New', 'book' ),
	  'add_new_item'       => __( 'Add New Team' ),
	  'edit_item'          => __( 'Edit Team' ),
	  'new_item'           => __( 'New Team' ),
	  'all_items'          => __( 'All Teams' ),
	  'view_item'          => __( 'View Team' ),
	  'search_items'       => __( 'Search Teams' ),
	  'not_found'          => __( 'No teams found' ),
	  'not_found_in_trash' => __( 'No teams found in the Trash' ), 
	  'parent_item_colon'  => '',
	  'menu_name'          => 'Teams'
	);
	$args = array(
	  'labels'        => $labels,
	  'description'   => 'Holds our teams and team specific data',
	  'public'        => true,
	  'menu_position' => 5,
	  'supports'      => array( 'title', 'editor', 'thumbnail', 'excerpt', 'comments' ),
	  'has_archive'   => true,
	);
	register_post_type( 'team', $args ); 
  }
  add_action( 'init', 'my_custom_post_team' );


add_action('acf/init', 'my_acf_op_init');
function my_acf_op_init() {

    // Check function exists.
    if( function_exists('acf_add_options_page') ) {

        // Register options page.
        $option_page = acf_add_options_page(array(
            'page_title'    => __('Theme General Settings'),
            'menu_title'    => __('Theme Settings'),
            'menu_slug'     => 'theme-general-settings',
            'capability'    => 'edit_posts',
            'redirect'      => false
        ));
    }
}
/*
define('WP_CONTENT_DIR', $_SERVER['DOCUMENT_ROOT'] . '/careo');
define('WP_CONTENT_URL', 'http://localhost/my-wp-project/careo');*/