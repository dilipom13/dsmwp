 var $ = jQuery.noConflict();
 jQuery(document).ready( function() {

    //$(document).foundation();
    load_news_list(1);
 });
$('.news-list-grid-sec').on('click','#more_posts', function(e){
        
        e.preventDefault();

        load_news_list();
        
 });
;
$('#cat_select').change(function(e)
{
    e.preventDefault();
    cat_slug = $(this).val();
    webi_event_param.cat_slug = cat_slug;
    webi_event_param.current_page = 1;
    load_news_list(1, cat_slug);

});
 function load_news_list(paged,cat_slug){


        if (typeof paged === 'undefined' || paged === null) {
            paged = webi_event_param.current_page;
            }
            if (typeof cat_slug === 'undefined' || cat_slug === null) {
            cat_slug = webi_event_param.cat_slug;
            }

            $.ajax({
            type: "POST",
            dataType: "json",
             url: webi_event_param.ajaxurl,
            data: {
                    "action": "load_more_post_data", 
                    'paged' : paged,
                    'cat_slug' : cat_slug,
                },
            beforeSend : function ( xhr ) {
            $('#loader-block').css("display","flex");
            },

            success : function( data ) {
            html_data = data.html_data;
            max_page = data.max_page;

            //$(document).foundation();

            if(html_data.length) 
            {
                
                if(paged==1)
                {
                    $('#webinar_event_container').html(html_data);
                }
                else
                {
                    $('#webinar_event_container').append(html_data);
                }
                if ( webi_event_param.current_page == max_page )
                {
                    $('#view_btn').hide();
                }
                else
                {
                    $('#view_btn').show();
                }
            } 
            else
            {
                $('#view_btn').hide();
            }
            webi_event_param.current_page++;

            $('#loader-block').hide();
            //$(document).foundation();
            }
    });
        return false;
}
/* Popup Script */
$(document).ready(function() {
$('.popup-player').magnificPopup({
    type: 'iframe',
    mainClass: 'mfp-fade',
    removalDelay: 160,
    preloader: false,
    fixedContentPos: false,
    iframe: {
        markup: '<div class="mfp-iframe-scaler">'+
                '<div class="mfp-close"></div>'+
                '<iframe class="mfp-iframe" allow="autoplay" frameborder="0" allowfullscreen></iframe>'+
              '</div>',

        srcAction: 'iframe_src',
        }
});
});
   