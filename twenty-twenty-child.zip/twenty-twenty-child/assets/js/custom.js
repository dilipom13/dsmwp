/******/ (function(modules) { // webpackBootstrap 
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ({

/***/ 10:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


/*function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

var $ = jQuery.noConflict();
var abc = [],
    usercolumn1 = [],
    enviColumn1 = [],
    buttonPush1 = [],
    usercolumn2 = [],
    enviColumn2 = [],
    buttonPush2 = [],
    usercolumn3 = [],
    enviColumn3 = [],
    buttonPush3 = [];
var db = void 0;
var request = window.indexedDB.open('priceList', 1);
var tableId = '',
    tablePressId = '';*/

function headerFix() {
	var headerHeight = $('.site-header').outerHeight();
	var ubBar = $('.ub-emb-bar-frame').outerHeight();
	var headerUbbar = ubBar + headerHeight;
	$('.site-wrap').css('padding-top', headerHeight);

	if ($('.ub-emb-bar')[0]) {
		$('.site-header').css('top', ubBar);
	} else {
		$('.site-header').css('top', '0');
	}

	$(window).scroll(function () {
		if (window.innerWidth <= 767) {
			if ($(window).scrollTop() >= 450) {
				$('body').addClass('top_fixed');
				$('.site-header').addClass('fixed');
				$('.site-wrap').css('padding-top', headerHeight);
			} else {
				$('body').removeClass('top_fixed');
				$('.site-header').removeClass('fixed');
				$('.site-wrap').css('padding-top', headerHeight);
			}
		} else {
			if ($(window).scrollTop() >= 450) {
				$('body').addClass('top_fixed');
				$('.site-header').addClass('fixed');
				$('.site-wrap').css('padding-top', headerHeight);
			} else {
				$('body').removeClass('top_fixed');
				$('.site-header').removeClass('fixed');
				$('.site-wrap').css('padding-top', headerHeight);
			}
		}
	});
}

$('.parallax').each(function () {
	$(this).css('transform', 'translate3d(0 , 0 , 0)');
});

function parallax() {
	var scroll = $(window).scrollTop();
	var screenHeight = $(window).height();

	$('.parallax').each(function () {
		var offset = $(this).offset().top;
		var distanceFromBottom = offset - scroll - screenHeight;

		if (offset > screenHeight && offset) {
			$(this).css({
				'transform': 'translate3d(0px, ' + distanceFromBottom * 0.2 + 'px, 0px)'
			});
		} else {
			$(this).css({
				'transform': 'translate3d(0px, ' + -scroll * 0.2 + 'px, 0px)'
			});
		}
	});
}

var flag;
const settings = {
	slidesToShow: 1,
	slidesToScroll: 1,
	mobileFirst: true,
	dots: false,
	adaptiveHeight: true,
	responsive: [{
		breakpoint: 768,
		settings: 'unslick'
	},]
}

function mobileOnlySlider() {
	if (!$('.pricing_row').hasClass('slick-initialized')) {
		setTimeout(function () {
			$('.pricing_row').slick(settings);
		}, 1000);
	}
}

$(window).resize(mobileOnlySlider);

function checkSliders() {
	if (window.innerWidth <= 767 && (typeof flag == 'undefined' || flag)) {
		flag = false;
		mobileOnlySlider();
	} else if (window.innerWidth > 767 && (typeof flag == 'undefined' || !flag)) {
		flag = true;
		destroySlider();
	}
}

mobileOnlySlider();

function destroySlider() {
	if ($('.pricing_row').hasClass('slick-initialized')) {
		setTimeout(function () {
			$('.pricing_row').slick('unslick');
		}, 800);
	}
}

(function ($) {
	$.fn.equalHeight = function (option) {
		var $this = this;
		var get_height = function get_height() {
			var maxheight = 0;
			$this.css('height', '');
			$this.each(function () {
				maxheight = $(this).height() > maxheight ? $(this).height() : maxheight;
			});
			$this.height(maxheight);
		};
		var init = function init() {
			get_height();
			$(window).bind('resize', get_height);
		};
		$this.destroy = function () {
			$this.css('height', '');
			$(window).unbind('resize', get_height);
		};
		init();
		return this;
	};
})(jQuery);

jQuery(document).ready(function () {
	// Site Loader
	//jQuery("#site-loader").remove();

	$('.close_search_icon').click(function () {
		$(this).parents('form').find('.searchInput').val('');
		$(this).parents('form').find('.submit_search_btn').css('opacity', '0');
		$(this).hide();
	});

	$('.searchInput').keyup(function () {
		var input = $(this);
		if (input.val() == '') {
			$('.close_search_icon').hide();
			$(this).parents('form').find('.submit_search_btn').css('opacity', '0');
		} else {
			$('.close_search_icon').show();
			$(this).parents('form').find('.submit_search_btn').css('opacity', '1');
		}
	});

	var headerHeight = $('.site-header').outerHeight();
	$(document).on('click', '.ub-emb-close', function () {
		//$(".site-wrap").css("padding-top", headerHeight);
		$('.site-header').css('top', '0');
	});

	// For change selected text - Product Dropdown Link
	jQuery('.product_dropdown li a').click(function () {
		var getVal = jQuery(this).text();
		// alert()
		jQuery('.product_dropdown_link span').text(getVal);
	});
	// Product Dropdown Menu
	jQuery('.product_dropdown li').click(function () {

		var aTag = jQuery(this).data('attr');
		jQuery('#etlChildTab .resp-tab-content').hide();
		jQuery('#etlChildTab .resp-tab-content[data-show=\'' + aTag + '\']').show();

		jQuery(this).addClass('active').siblings().removeClass('active');
		jQuery(this).addClass('active');
		$('.product-slider').slick('reinit');
		//jQuery('#tablepress-8 .column-3 .product-slider').slick('slickNext');
		//jQuery('#tablepress-9 .column-3 .product-slider').slick('slickNext');
	});

	// if ($('.card-description').length) {
	// 	$('.add-card-slider').slick({
	// 		slidesToShow: 1,
	// 		slidesToScroll: 3,
	// 		centerMode: true,
	// 		centerPadding: '30%',
	// 		infinite: true,
	// 		arrows: false,
	// 		asNavFor: '.card-description',
	// 		focusOnSelect: true,
	// 		responsive: [{
	// 			breakpoint: 767,
	// 			settings: {
	// 				slidesToShow: 1,
	// 				slidesToScroll: 1,
	// 				draggable: false,
	// 				centerPadding: '0%'
	// 			}
	// 		}]
	// 	});
	//
	// 	$('.card-description').slick({
	// 		slidesToShow: 1,
	// 		slidesToScroll: 1,
	// 		arrows: false,
	// 		adaptiveHeight: true,
	// 		draggable: true,
	// 		dots: true,
	// 		asNavFor: '.add-card-slider'
	// 	});
	// } else {
	// 	$('.add-card-slider').slick({
	// 		slidesToShow: 1,
	// 		slidesToScroll: 3,
	// 		dots: true,
	// 		centerMode: true,
	// 		centerPadding: '32%',
	// 		arrows: false,
	// 		focusOnSelect: true,
	// 		responsive: [{
	// 			breakpoint: 767,
	// 			settings: {
	// 				slidesToShow: 1,
	// 				slidesToScroll: 1,
	// 				centerPadding: '0%',
	// 				focusOnSelect: true
	// 			}
	// 		}]
	// 	});
	// }

	$('#menu-footer-menu > li').append('<span class="footer-nav-icon"></span>');
	$('.footer-nav-icon').click(function () {
		$('.footer-nav-icon').removeClass('opened');
		$(this).toggleClass('opened');
		$(this).parents('ul').find('.sub-menu').slideUp();
		$(this).parent('li').find('.sub-menu').slideToggle();
	});

	$('.mob_filter_dropdown').click(function () {
		$(this).next('#menubar').slideToggle();
		$(this).toggleClass('open').siblings();
	});

	$('.menubar > li > a').click(function () {
		if ($(this).hasClass('open')) {
			$(this).removeClass('open');
		} else {
			$('.menubar > li > a').removeClass('open');
			$(this).addClass('open');
		}
	});

	headerFix();

	jQuery('.mega-search-wrap .search-btn').on('click', function () {
		var input = $(this).closest('.mega-search').find('input[type=\'text\']');
		var form = $(this).closest('.mega-search');

		if (!form.hasClass('mega-search-open')) {

			setTimeout(function () {
				form.addClass('mega-search-open');
			}, 320);

			jQuery('body').addClass('search-box-open');
			input.focus();
		} else {
			if (input.val() == '') {
				form.removeClass('mega-search-open');
				jQuery('body').removeClass('search-box-open');
			} else {
				form.submit();
			}
		}
	});

	if (window.innerWidth >= 767) {
		$('.pri_wrap #1 .pricing_col_footer').equalHeight();
		$('.pri_wrap #2 .pricing_col_footer').equalHeight();
		$('.pri_wrap #3 .pricing_col_footer').equalHeight();
	}

	// For Table Desktop Dropdown menu
	jQuery(document).on('click', '.modal_link', function () {
		if (window.innerWidth >= 767) {
			if ($(this).hasClass('open')) {
				$(this).removeClass('open');
			} else {
				$('.modal_link').removeClass('open');
				$(this).addClass('open');
			}
			jQuery('.revealDropdown').slideUp();
			jQuery(this).next('.revealDropdown').stop().slideToggle();
		}
	});

	// For Table Mobile Modal
	jQuery(document).on('click', '.modal_link', function () {
		var modalContent = $(this).next('.revealDropdown').html();
		var modalTitle = $(this).html();
		if (window.innerWidth <= 767) {
			jQuery('body').addClass('openModal');
			$('body').append($('<div id="modalOverlay"></div>').html('<h4>' + modalTitle + '</h4>' + modalContent + '<a href="javascript:void(0);" class="close_btn">close</a>'));
		}
	});

	// For Table Mobile Modal Close
	jQuery(document).on('click', '.close_btn', function () {
		if (window.innerWidth <= 767) {
			jQuery('body').removeClass('openModal');
			jQuery('#modalOverlay').remove();
		}
	});

	// Tablepress
	$('.thead').parents('tr').addClass('thead-child');
	$('.tfoot').parents('tr').addClass('tfoot-child');
	$('.tHeader').parents('tr').addClass('td-header');

	// Table Mobile Slider
	$('.table_slider').slick({
		slidesToShow: 1,
		slidesToScroll: 1,
		dots: false,
		adaptiveHeight: true,
		fade: true,
		speed: 0,
		infinite: true
	});

	jQuery('.enumenu_ul').responsiveMenu({
		'menuIcon_text': '',
		menuslide_overlap: true,
		menuslide_direction: 'right',
		onMenuopen: function onMenuopen() {}
	});

	if ($('.partners-slider').length) {
		$('.partners-slider').slick({
			infinite: true,
			autoplay: true,
			autoplaySpeed: 2000,
			slidesToShow: 6,
			slidesToScroll: 1,
			responsive: [{
				breakpoint: 1200,
				settings: {
					slidesToShow: 5
				}
			}, {
				breakpoint: 767,
				settings: {
					slidesToShow: 4
				}
			}, {
				breakpoint: 640,
				settings: {
					slidesToShow: 2
				}
			}, {
				breakpoint: 480,
				settings: {
					slidesToShow: 1
				}
			}]
		});
	}

	if ($('.product-slider').length) {
		$('.product-slider').slick({
			infinite: false,
			slidesToShow: 1,
			slidesToScroll: 1,
			dots: false
		});
	}
	if ($('.video-testimonial-slider').length) {
		$('.video-testimonial-slider').slick({
			infinite: true,
			slidesToShow: 3,
			slidesToScroll: 1,
			dots: true
		});
	}

	if ($('.card-slider').length) {
		$('.card-slider').slick({
			infinite: true,
			slidesToShow: 2,
			slidesToScroll: 2,
			dots: true,
			arrows: false,

			responsive: [{
				breakpoint: 767,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					adaptiveHeight: false
				}
			}, {
				breakpoint: 640,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					adaptiveHeight: false
				}
			}, {
				breakpoint: 480,
				settings: {
					slidesToShow: 1,
					slidesToScroll: 1,
					adaptiveHeight: false
				}
			}]
		});
	}
	if ($('.testimonials_carousel').length) {
		$('.testimonials_carousel').slick({
			infinite: true,
			slidesToShow: 1,
			slidesToScroll: 1,
			dots: true,
			arrows: false
		});
	}
	if ($('.add-testimonial-slider').length) {
		$('.add-testimonial-slider').slick({
			infinite: true,
			slidesToShow: 1,
			slidesToScroll: 1,
			dots: true,
			arrows: false
		});
	}

	if ($('#slider .slide').length > 1) {
		window.slider = $('#slider').cardSlider({
			slideTag: 'div',
			slideClass: 'slide',
			current: 1,
			followingClass: 'slider-content-6',
			delay: 10,
			transition: 'ease',
			onBeforeMove: function onBeforeMove(slider, onMove) {
				onMove();
			},
			onMove: function onMove(slider, onAfterMove) {
				onAfterMove();
			},
			onAfterMove: function onAfterMove() {},
			onAfterTransition: function onAfterTransition() {},
			onCurrent: function onCurrent() {}
		});
	} else {
		$('#slider').addClass('no-slider');
		$('.slider-counter').hide();
	}

	var win_height = $(window).height();
	var count_height = win_height / 1;

	if ($('.show-on-scroll').length) {
		$('.show-on-scroll').each(function () {
			var $that = $(this);
			var at_top_block = $that.offset().top - count_height;
			if ($(window).scrollTop() >= at_top_block) {
				$that.addClass('show-element');
			}
		});
	}

	if ($('.one-by-one').length) {
		$('.one-by-one .hidden-element').each(function () {
			var $that = $(this);
			var at_top_block = $that.offset().top - count_height;
			if ($(window).scrollTop() >= at_top_block) {
				$('.one-by-one .hidden-element').each(function (i) {
					var $li = $(this);
					setTimeout(function () {
						$li.addClass('show-element');
					}, i * 200); // delay 100 ms
				});
			}
		});
	}

	$('.get-demo').magnificPopup({
		type: 'inline',
		preloader: false,
		focus: '#name',
		callbacks: {
			beforeOpen: function () {
				if ($(window).width() < 700) {
					this.st.focus = false;
				} else {
					this.st.focus = '#name';
				}
			}
		}
	});
	$('.openBox').magnificPopup({
		type: 'inline',
		preloader: false,
		focus: '#name',
		callbacks: {
			beforeOpen: function () {
				if ($(window).width() < 700) {
					this.st.focus = false;
				} else {
					this.st.focus = '#name';
				}
			}
		}
	});
});

jQuery(window).on('load', function () {
	//snowflake array end//
	headerFix();

	$('.slider-content-6').click(function () {
		var selector = $(this).data('slide');
		$('.slide[data-iteam=\'' + selector + '\']').trigger('click');
	});

	jQuery('#lever-jobs-container .lever-team li, .lever-jobs-container .lever-team li').find('ul').stop().slideUp().removeClass('active');
	jQuery('.lever-team-title').removeClass('active');

	jQuery('body').on('click', '.lever-team-title', function (e) {
		jQuery('#lever-jobs-container .lever-team li, .lever-jobs-container .lever-team li').find('ul').stop().slideUp().removeClass('active');
		jQuery('.lever-team-title').removeClass('active');
		jQuery(this).closest('#lever-jobs-container .lever-team li, .lever-jobs-container .lever-team li').find('ul').stop().slideToggle();
		jQuery(this).addClass('active');
	});

	jQuery('body').on('click', '.lever-team-title.active', function (e) {
		jQuery(this).removeClass('active');
	});

	// new
	jQuery('.record-cover .record-cover-box').find('.glossary_content').stop().slideUp().removeClass('active');

	jQuery('.record-cover-box h4').removeClass('active');

	jQuery('body').on('click', '.record-cover-box h4', function (e) {
		jQuery('.record-cover .record-cover-box').find('.glossary_content').stop().slideUp().removeClass('active');
		jQuery('.record-cover-box h4').removeClass('active');
		jQuery(this).closest('.record-cover .record-cover-box').find('.glossary_content').stop().slideToggle();
		jQuery(this).addClass('active');
	});

	jQuery('body').on('click', '.record-cover-box h4.active', function (e) {
		jQuery(this).removeClass('active');
	});

	jQuery('body').on('click', '.pagination a', function (e) {
		jQuery('html, body').animate({
			scrollTop: jQuery('.recent_news_block').offset().top
		}, 1000);
	});

	jQuery('.scroll-to').click(function () {
		jQuery('html, body').animate({
			scrollTop: jQuery('.button-cta-block').offset().top
		}, 2000);
	});
});

$(window).scroll(function () {
	var win_height = $(window).height();
	var count_height = win_height / 1.2;

	parallax();

	if ($('.show-on-scroll').length) {
		$('.show-on-scroll').each(function () {
			var $that = $(this);
			var at_top_block = $that.offset().top - count_height;

			if ($(window).scrollTop() >= at_top_block) {
				$that.addClass('show-element');
			}
		});
	}

	if ($('.one-by-one').length) {
		$('.one-by-one .hidden-element').each(function () {
			var $that = $(this);
			var at_top_block = $that.offset().top - count_height;
			if ($(window).scrollTop() >= at_top_block) {
				$('.one-by-one .hidden-element').each(function (i) {
					var $li = $(this);
					setTimeout(function () {
						$li.addClass('show-element');
					}, i * 250); // delay 100 ms
				});
			}
		});
	}
});

$(window).resize(function () {
	headerFix();
});

jQuery(document).ready(function () {
	if (window.innerWidth <= 767) {
		jQuery('#tablepress-5 .column-3 .product-slider').slick('slickNext');
	}

	var $easy_tabs_exist = jQuery('#pricingTabs').length || jQuery('#childTab').length || jQuery('#etlChildTab').length;

	if ($easy_tabs_exist) {
		jQuery('#pricingTabs').easyResponsiveTabs({
			type: 'default', //Types: default, vertical, accordion
			width: 'auto', //auto or any width like 600px
			fit: true, // 100% fit in a container
			tabidentify: 'hor_1', // The tab groups identifier
			removeHashfrmUrl: true,
			activate: function activate() {
				// if(window.innerWidth>=767){
				// jQuery(".pricing_row").slick('unslick');
				// }
				//mobileOnlySlider();
			}
		});

		// Child Tab
		jQuery('#childTab').easyResponsiveTabs({
			type: 'default',
			width: 'auto',
			fit: true,
			tabidentify: 'ver_1', // The tab groups identifier
			removeHashfrmUrl: true,
			//activetab_bg: '#fff', // background color for active tabs in this group
			//inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
			//active_border_color: '#c1c1c1', // border color for active tabs heads in this group
			//active_content_border_color: '#5AB1D0' // border color for active tabs contect in this group so that it matches the tab head border
			activate: function activate() {
				// if(window.innerWidth>=767){
				// jQuery(".pricing_row").slick('unslick');
				// }
				// mobileOnlySlider();
			}
		});

		// Child Tab
		jQuery('#etlChildTab').easyResponsiveTabs({
			type: 'default',
			width: 'auto',
			fit: true,
			tabidentify: 'ver_2', // The tab groups identifier
			removeHashfrmUrl: true
			//activetab_bg: '#fff', // background color for active tabs in this group
			//inactive_bg: '#F5F5F5', // background color for inactive tabs in this group
			//active_border_color: '#c1c1c1', // border color for active tabs heads in this group
			//active_content_border_color: '#5AB1D0' // border color for active tabs contect in this group so that it matches the tab head border
		});
	}

  //jQuery('.pricingTabs .resp-tab-item').eq(1).trigger('click');
	// if (window.location.hash) {
	  
	// 	var target_ = window.location.hash.substr(1);
	// 	if (!$("[data-id='"+target_+"']").length) {
    // //   jQuery(".pricingTabs .resp-tab-item").eq(1).trigger("click");
    // } else {
    // //   jQuery("[data-id='"+target_+"']").trigger("click");
    // }
	// } else {
	// 	// jQuery('.pricingTabs .resp-tab-item').eq(1).trigger('click');
	// }

	if ($('.pricingTabs').length) {
		if (window.location.hash.split('?')[0] == '#matillion-dataloader') {
			$('#switch').prop('checked', true);
		}

		var active_child = false;

		// if (window.location.hash.split('?')[0] == '#matillion-etl') {

			$('#etlChildTab .resp-tab-item').each(function () {
				if ($(this).hasClass('resp-tab-active')) {
					active_child = true;
				}
			});

			if (!active_child) {
				$('#etlChildTab .resp-tab-item:first-child').addClass('resp-tab-active');
			}
		// }h
	}

	$('.resp-tab-item').click(function () {
		if (window.innerWidth >= 767) {
			$('.pri_wrap #1 .pricing_col_footer').equalHeight();
			$('.pri_wrap #2 .pricing_col_footer').equalHeight();
			$('.pri_wrap #3 .pricing_col_footer').equalHeight();
		}

		if (window.innerWidth >= 768) {
			destroySlider();
		}
	});

	function switchbutton() {
		$('.pricingTabs > ul > li:first').each(function () {
			if ($(this).hasClass('resp-tab-active')) {
				$(this).parents('.pricingTabsWrap').find('#switch').prop('checked', false);
			} else {
				$(this).parents('.pricingTabsWrap').find('#switch').prop('checked', true);
			}
		});
	}

	$('.pricingTabs > ul > li').click(function () {
		switchbutton();
	});

	$('#switch').on('change', function () {
		if ($(this).is(':checked')) {
			$('.pricingTabs .resp-tab-item').eq(1).trigger('click');
		} else {
			$('.pricingTabs .resp-tab-item').eq(0).trigger('click');
		}
	});
});

/*---- Start Data Glossary Page Js ----*/
$(document).ready(function () {
	$('ul.cat_list li a').click(function (e) {
		$(this).parent().addClass('selected').siblings().removeClass('selected');

		e.preventDefault();
		var post_title_alpha = jQuery(this).text();
		jQuery.ajax({
			url: ajax_object.ajaxurl,
			type: 'POST',
			data: {
				action: 'myaction',
				post_id: post_title_alpha
			},
			success: function success(data) {
				jQuery('.list_recod_dd').html(data);
			}
		});
	});

	//------- Start Click Press Filter Record------------
	$(document).on('click', '#search_buuton', function (e1) {
		$('.cat_list li').removeClass('selected');
		var post_title = jQuery('#filter_title_record').val();
		var trimStr = jQuery.trim(post_title);
		if (trimStr !== '') {
			jQuery.ajax({
				url: ajax_object.ajaxurl, // this is the object instantiated in wp_localize_script function
				type: 'POST',
				data: {
					action: 'myaction',
					post_search_title: trimStr
				},
				success: function success(data) {
					jQuery('.list_recod_dd').html(data);
					jQuery('li.glossary_content').addClass('intro');
				}
			});
		}
		e1.stopPropagation();
	});
	//------- End Click Press Filter Record ------------

	//------- Start Enter Press Filter Record------------
	jQuery('#filter_title_record').keypress(function (event) {
		var keycode = event.keyCode ? event.keyCode : event.which;
		if (keycode == '13') {
			var post_title = jQuery('#filter_title_record').val();
			var trimStr = jQuery.trim(post_title);
			if (trimStr != '') {
				jQuery.ajax({
					url: ajax_object.ajaxurl,
					type: 'POST',
					data: {
						action: 'myaction',
						post_search_title: trimStr
					},
					success: function success(data) {
						jQuery('.list_recod_dd').html(data);
						jQuery('li.glossary_content').addClass('intro');
					}
				});
			}
		}
		event.stopPropagation();
	});

	//------------------ Start Load More------------------
});

/*---- End Data Glossary Page Js ----*/

function destroySlider() {
	if ($('.pricing_row:visible').hasClass('slick-initialized')) {
		$('.pricing_row:visible').slick('unslick');
	}
}

// function initSlider() {
// 	if ($('.pricing_row:visible').hasClass('slick-initialized')) {
// 		$('.pricing_row:visible').slick('unslick');
// 	}
//
// 	if (!$('.pricing_row:visible').hasClass('slick-initialized')) {
// 		$('.pricing_row:visible').slick({
// 			  infinite: false,
//     		  slidesToShow: 1,
//     		  responsive: [{
// 			        breakpoint: 640,
// 			        settings: {
// 			            infinite: false,
// 						slidesToShow: 1,
// 						dots: false
// 			        }
// 			    }, {
// 			        breakpoint: 320,
// 			        settings: {
// 			            infinite: false,
// 						slidesToShow: 1,
// 						dots: false
// 			        }
// 			    }]
//
// 		});
// 	}
// }

$(window).resize(function () {
	if (window.innerWidth > 767) {
		destroySlider();
	}
});

$(document).ready(function () {
	/*if (window.innerWidth <= 767) {
		var msg = '';

		$('.tHeader').each(function (i, el) {
			abc.push(jQuery(this).text());
			[].concat(_toConsumableArray(new Set(abc)));
		});

		$('#tablepress-5 .row-2 td').not(':first').each(function (i, el) {
			usercolumn1.push($(el).html());
		});
		$('#tablepress-5 .row-3 td').not(':first').each(function (i, el) {
			enviColumn1.push($(el).html());
		});
		$('#tablepress-5 .tfoot-child td').not(':first').each(function (i, el) {
			buttonPush1.push($(el).html());
		});

		$('#tablepress-8 .row-2 td').not(':first').each(function (i, el) {
			usercolumn2.push($(el).html());
		});
		$('#tablepress-8 .row-3 td').not(':first').each(function (i, el) {
			enviColumn2.push($(el).html());
		});
		$('#tablepress-8 .tfoot-child td').not(':first').each(function (i, el) {
			buttonPush2.push($(el).html());
		});

		$('#tablepress-9 .row-2 td').not(':first').each(function (i, el) {
			usercolumn3.push($(el).html());
		});
		$('#tablepress-9 .row-3 td').not(':first').each(function (i, el) {
			enviColumn3.push($(el).html());
		});
		$('#tablepress-9 .tfoot-child td').not(':first').each(function (i, el) {
			buttonPush3.push($(el).html());
		});

		var employeeData = [],
		    employeeData2 = [],
		    employeeData3 = [],
		    getDetails,
		    getDetails2,
		    getDetails3;
		[].concat(_toConsumableArray(new Set(abc))).map(function (el, i) {
			console.log(el);
			console.log(usercolumn1[i]);
			console.log(enviColumn1[i]);
			var a = buttonPush1[i].replace(/"/g, '');
			getDetails = { type: el, Users: usercolumn1[i], Environments: enviColumn1[i], buttons: a };
			console.log(employeeData.push(getDetails));
		});
		[].concat(_toConsumableArray(new Set(abc))).map(function (el, i) {
			console.log(el);
			console.log(usercolumn3[i]);
			console.log(enviColumn3[i]);
			var a = buttonPush3[i].replace(/"/g, '');
			console.log(a);
			getDetails3 = { type: el, Users: usercolumn3[i], Environments: enviColumn3[i], buttons: a };
			console.log(employeeData3.push(getDetails3));
		});
		[].concat(_toConsumableArray(new Set(abc))).map(function (el, i) {
			console.log(el);
			console.log(usercolumn2[i]);
			console.log(enviColumn2[i]);
			var a = buttonPush2[i].replace(/"/g, '');
			console.log(a);
			getDetails2 = { type: el, Users: usercolumn2[i], Environments: enviColumn2[i], buttons: a };
			console.log(employeeData2.push(getDetails2));
		});

		request.onerror = function (event) {
			console.log('error: ');
		};

		request.onsuccess = function (event) {
			db = request.result;
			console.log(db);
			console.log('success: ' + db);
		};

		request.onupgradeneeded = function (event) {
			var db = event.target.result;
			var objectStore = db.createObjectStore('priceTable1', { keyPath: 'type' });
			var objectStore2 = db.createObjectStore('priceTable2', { keyPath: 'type' });
			var objectStore3 = db.createObjectStore('priceTable3', { keyPath: 'type' });
			for (var i in employeeData) {
				console.log(employeeData[i]);
				objectStore.add(employeeData[i]);
			}
			for (var i in employeeData2) {
				console.log(employeeData2[i]);
				objectStore2.add(employeeData2[i]);
			}
			for (var i in employeeData3) {
				console.log(employeeData3[i]);
				objectStore3.add(employeeData3[i]);
			}
		};
	}*/

	jQuery('ul.product_dropdown li').click(function () {
		$('.pricing_row').slick('refresh');
		if (window.innerWidth <= 767) {
			var this_ = $(this);
			/*if ($('#tablepress-5').is(':visible')) {
				console.log($('#tablepress-5').find('.column-2').find('.slick-current').find('.tHeader').text());
				console.log($('#tablepress-5').find('.column-3').find('.slick-current').find('.tHeader').text());
				var transaction = db.transaction(['priceTable1']);
				var objectStore = transaction.objectStore('priceTable1');
				var request1 = objectStore.get($('#tablepress-5').find('.column-2').find('.slick-current').find('.tHeader').text());
				var request2 = objectStore.get($('#tablepress-5').find('.column-3').find('.slick-current').find('.tHeader').text());
				console.log(request1);
				console.log(request2);
				setTimeout(function () {
					$('#tablepress-5 .row-2 .column-3').html(request2.result.Users);
					$('#tablepress-5 .row-3 .column-3').html(request2.result.Environments);
					$('#tablepress-5 .tfoot-child .column-3').html(request2.result.buttons);
				}, 800);
			}
			if ($('#tablepress-8').is(':visible')) {
				console.log($('#tablepress-8').find('.column-2').find('.slick-current').find('.tHeader').text());
				console.log($('#tablepress-8').find('.column-3').find('.slick-current').find('.tHeader').text());
				var transaction = db.transaction(['priceTable2']);
				var objectStore = transaction.objectStore('priceTable2');
				var request1 = objectStore.get($('#tablepress-8').find('.column-2').find('.slick-current').find('.tHeader').text());
				var request2 = objectStore.get($('#tablepress-8').find('.column-3').find('.slick-current').find('.tHeader').text());
				console.log(request1);
				console.log(request2);
				setTimeout(function () {
					$('#tablepress-8 .row-2 .column-3').html(request2.result.Users);
					$('#tablepress-8 .row-3 .column-3').html(request2.result.Environments);
					$('#tablepress-8 .row-20 .column-3').html(request2.result.buttons);
				}, 800);
			}

			if ($('#tablepress-9').is(':visible')) {
				console.log($('#tablepress-9').find('.column-2').find('.slick-current').find('.tHeader').text());
				console.log($('#tablepress-9').find('.column-3').find('.slick-current').find('.tHeader').text());
				var transaction = db.transaction(['priceTable3']);
				var objectStore = transaction.objectStore('priceTable3');
				var request1 = objectStore.get($('#tablepress-9').find('.column-2').find('.slick-current').find('.tHeader').text());
				var request2 = objectStore.get($('#tablepress-9').find('.column-3').find('.slick-current').find('.tHeader').text());
				console.log(request1);
				console.log(request2);
				setTimeout(function () {
					$('#tablepress-9 .row-2 .column-3').html(request2.result.Users);
					$('#tablepress-9 .row-3 .column-3').html(request2.result.Environments);
					$('#tablepress-9 .row-20 .column-3').html(request2.result.buttons);
				}, 800);
			}*/
		}
	});
});

/***/ }),

/***/ 9:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(10);


/***/ })

/******/ });
