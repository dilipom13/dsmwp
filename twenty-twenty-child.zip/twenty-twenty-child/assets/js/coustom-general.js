jQuery(function($)
{
    get_blog_list_load(1)

    //Main ajax function
    function get_blog_list_load(paged)
    {
        var paged_value = paged;
        var ajax_url = ajax_coustom_general_params.ajax_url;

        $.ajax({
			type: 'GET',
			url: ajax_url,
			data: {
				action: 'general_dat_filter',
				paged: paged_value
			},
			beforeSend: function ()
			{
				//Show loader here
			},
			success: function(data)
			{
				//Hide loader here
				$('#genre-list-blog-results').html(data);
			},
			error: function()
			{
				$("#genre-list-blog-results").html('<p>There has been an error</p>');
			}
		});
                    
    }
});
